# Picture-Sorter
Python sort visualizer running pygame that sorts the pixels in an image using merge sort

Takes any image and uses merge sort to sort the pixels of an image by the HSL value with a visualizer showing the transition.

![before](https://user-images.githubusercontent.com/26195368/185802287-30ac6866-5154-4a3c-97c3-efcbe37a8980.PNG)

![after](https://user-images.githubusercontent.com/26195368/185802283-03d87aa0-406d-4d00-838b-3b7f87d641e7.PNG)
